class Recruit {
    constructor(data) {
        console.log(data)
        this.rightList = document.getElementById('rightList');
        this.leftLi = document.querySelectorAll('#leftList li');
        this.nav = document.getElementById('nav');
        this.data = data;
        this.dataName = 'sh';
        this.page = 1;
        this.render(this.data, this.dataName);
        this.eventSwitch();
        this.pageChange();
        this.hashChange();
        this.pageEvent();
    }
    render(data, dataName) {
        //dataName可获取到社会招聘/校园招聘对应的数据
        // let { add0, formateDate } = data;
        // console.log(data.add0(2));

        let page = 1;
        let html = '';

        /* 
            第1页：0~3
            第2页：4~7
            第3页：8~11
            第4页：12~15
            规律：(页数-1)*4 ~ (页数*4-1)

        */

        for (let i = (page - 1) * 4; i < page * 4; i++) {
            html += `<li>
            <span class="num">${data.add0(i + 1)}</span>
            <div class="list">
                <a href=""><span class="job">职位需求：${data[dataName].text[i].zw}</span><span>需求人数：${data[dataName].text[i].rs}名</span><time>${data.formateDate(data[dataName].text[i].sj)}</time></a>
                <p><span class="text">${data[dataName].text[i].info[0].l.join('')}</span><a href="javascript:;">查看详情>></a></p>
            </div>
        </li>`
        }
        this.rightList.innerHTML = html;
    }
    eventSwitch() {
        // 点击校园招聘/社会招聘，切换内容，同时改变样式
        let that = this;
        let leftLiOne = this.leftLi[0];
        for (let i = 0; i < this.leftLi.length; i++) {
            this.leftLi[i].onclick = function () {
                leftLiOne.className = ''
                this.className = 'active';
                leftLiOne = this;
                that.dataName = data.list[i].lx;
                that.render(data, that.dataName);
            }
        }
    }
    pageChange() {
        // 渲染页数
        this.pageNum = Math.ceil(data[this.dataName].text.length / 4);
        let html = '';
        html = '<a href="javascript:;">&lt;</a>';
        for (let i = 1; i <= this.pageNum; i++) {
            html += `<a href="javascript:;">${i}</a>`
        }
        html += '<a href="javascript:;">&gt;</a>';
        this.nav.innerHTML = html
    }
    pageEvent() {
        //点击页数显示对应的页面，点击左右箭头显示上一页下一页
        let that = this;
        this.nav.onclick = function (ev) {
            if (that.page < 1) that.page = 1;
            if (that.page > that.pageNum-1) that.page = that.pageNum;

            if (ev.target.innerHTML === '&lt;') {
                that.page--;
                console.log(that.page);
            };
            if (ev.target.innerHTML === '&gt;') {
                that.page++;
                console.log(that.page);
            };
            if(ev.target.tagName === 'A'){
                
            }
            that.render(data, that.dataName);
        }
    }
    hashChange() {
        window.location.hash = `#hash=${this.dataName}&page=1`
    }
}
new Recruit(data);